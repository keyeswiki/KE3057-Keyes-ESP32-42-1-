from machine import Pin
import time

sensor = Pin(5, Pin.IN, Pin.PULL_UP)
last_state = sensor.value()  # 初始化为当前状态
push_counter = 0
DEBOUNCE_MS = 50  # 消抖时间（毫秒）

while True:
    current_state = sensor.value()
    if current_state != last_state:
        time.sleep_ms(DEBOUNCE_MS)  # 等待消抖
        if sensor.value() == 1:     # 确认上升沿
            push_counter += 1
            print(push_counter)
    last_state = current_state